package com.moxtra.calendarview;

import android.app.Activity;
import android.app.Dialog;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.googlecode.android.widgets.DateSlider.SliderContainer;

import java.util.Calendar;


public class MainActivity extends Activity {
    private String TAG = "MainActivity";
    private TextView dateText;
    private ListView dateText1;
    static final int DEFAULTDATESELECTOR_ID = 0;

    protected SliderContainer mContainer;
    protected Calendar mInitialTime, minTime, maxTime;
    protected int minuteInterval = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dateText = (TextView) this.findViewById(R.id.selectedDateLabel);

        Calendar initialTime = Calendar.getInstance();
        mInitialTime = Calendar.getInstance(initialTime.getTimeZone());
        mInitialTime.setTimeInMillis(initialTime.getTimeInMillis());
        mContainer = (SliderContainer) this.findViewById(R.id.dateSliderContainer);

        mContainer.setOnTimeChangeListener(onTimeChangeListener);
        mContainer.setMinuteInterval(minuteInterval);
        mContainer.setTime(mInitialTime);
        maxTime = Calendar.getInstance();
        maxTime.add(Calendar.DAY_OF_MONTH, 14);
        minTime = initialTime;
//        if (minTime!=null) mContainer.setMinTime(minTime);
        if (maxTime!=null) mContainer.setMaxTime(maxTime);
    }
    private SliderContainer.OnTimeChangeListener onTimeChangeListener = new SliderContainer.OnTimeChangeListener() {

        public void onTimeChange(Calendar time) {
//            Log.e(TAG, "onTimeChange" + mContainer.getTime());
            Calendar selectedDate = mContainer.getTime();
            dateText.setText(String.format("The chosen date:%n%te. %tB %tY", selectedDate, selectedDate, selectedDate));
        }
    };

}
